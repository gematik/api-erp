Dieses ZIP-File enthält eine Auswahl von verschiedenen GKV-Rezepten.
Damit sie vom Fachdienst akzeptiert werden, 
müssen folgende Platzhalter mit realen Werten gemäß der KBV-Festlegungen belegt werden:

- INSERT_yyyy-mm-dd_HERE
- INSERT_PATIENT-KVNR_HERE
- INSERT_LANR_THAT_FITS_AMVV-§2_HERE_AND_CHECK_OTHER_PRACTITIONER_ATTRs
- INSERT_KASSEN-NAME_HERE_MAXLENGTH_STRING_IS_45
- INSERT_KASSEN-IK_HERE